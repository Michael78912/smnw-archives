from time import sleep
import os


while True:
    os.system('python format.py')
    sleep(10 * 60)
