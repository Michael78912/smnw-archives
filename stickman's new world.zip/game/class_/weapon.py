from _internal import *
print(PICS)
class Sword:
	possible_images = PICS['weapons']['swords']
	def __init__(self, colour, level):
		...
		