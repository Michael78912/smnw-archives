"""smr_error.py- base class for 
stickmanranger errors.
"""

class SMRError(Exception):
    """
    base class for stickmanranger errors
    """
    pass