# this is a stupid comment
pass
import sys
import threading

try:
    import chwsuakeuegy

except Exception as l:
    d = l

def raise_d():
    raise d

sys.stderr = open('C:\\users\\michael\\desktop\\stderr.txt', 'w')

def raise_d():
    raise d


raise_d()
print('??')
sys.stderr.close()